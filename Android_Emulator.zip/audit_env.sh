# Source this in any terminal before running an audited mobile app:
export AUDIT_BACKEND_PORT="5001"
export AUDIT_BACKEND_URL="http://10.0.2.2:5001"
